<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_characteristic extends Model
{

   protected $fillable = ['characteristic_id', 'product_uuid', 'value'];



}
