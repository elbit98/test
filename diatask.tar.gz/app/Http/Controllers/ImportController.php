<?php

namespace App\Http\Controllers;

use App\Category;
use App\Characteristic;
use App\Product;
use App\Product_characteristic;
use App\Traits\ConverterTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Str;


class ImportController extends Controller
{

    use ConverterTrait;

    public function select() {
        return Category::where('uuid', '58671530-cbfc-4a68-bd78-8fcece740315')->first()->products;

    }

    public function import(Request $request)
    {

      $Tires = $request->Tires;
      $Category = $this->createCategory('Tires');

        $counter = 0;
        while ($counter !== 100)
        {
            $name = $this->valueGenerate($Tires,'Brands').' '.$this->valueGenerate($Tires,'Models');

            $uuidProduct = $this->createProduct($name, $Category->uuid)->uuid;

            $this->addCharacteristicInProduct($Tires['Characteristics'], $uuidProduct);

            $counter += 1;
        }



        return 'ok';

    }   


    public function createCategory($name) {
        return Category::create(['name' => $name, 'uuid' => Str::uuid(10), 'slug' => $this->slug($name)]);
    }

    public function createProduct($name,$uuidCategory) {
        return Product::create([
            'name' => $name,
            'uuid' => Str::uuid(10),
            'slug' => $this->slug($name),
            'category_uuid' => $uuidCategory,
            'price' => mt_rand(100,999),
        ]);
    }

    public function addCharacteristicInProduct($Characteristics, $uuidProduct) {

        foreach ($Characteristics as $key => $value) {

            Product_characteristic::create([
                'characteristic_id' => Characteristic::where('name', $key)->first()->id,
                'product_uuid' => $uuidProduct,
                'value' => $value[array_rand($value, 1)],
            ]);

        }
    }


}